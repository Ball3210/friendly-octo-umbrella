import picar_4wd as fc
import time

power = 10
time_turn = 1.0

if __name__ == '__main__':
    for _ in range(12):
        
        fc.turn_left(power)
        #fc.turn_right(power)
        #fc.forward(power)
        time.sleep(time_turn)
        fc.stop()
        time.sleep(1)
