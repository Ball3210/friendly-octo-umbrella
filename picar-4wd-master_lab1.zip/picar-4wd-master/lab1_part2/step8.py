import numpy as np
import picar_4wd as fc
import time
import argparse
import sys
import time
import cv2
from tflite_support.task import core
from tflite_support.task import processor
from tflite_support.task import vision
import traceback


power = 10
time_turn_left = 1.46
time_turn_right = 1.46
time_forward = 0.044


class Node():
    """A node class for A* Pathfinding"""

    def __init__(self, parent=None, position=None):
        self.parent = parent
        self.position = position

        self.g = 0
        self.h = 0
        self.f = 0

    def __eq__(self, other):
        return self.position == other.position


def astar(maze, start, end):
    """Returns a list of tuples as a path from the given start to the given end in the given maze"""
    start = w2i(start)
    end = w2i(end)

    # Create start and end node
    start_node = Node(None, start)
    start_node.g = start_node.h = start_node.f = 0
    end_node = Node(None, end)
    end_node.g = end_node.h = end_node.f = 0

    # Initialize both open and closed list
    open_list = []
    closed_map = np.zeros_like(maze)

    # Add the start node
    open_list.append(start_node)

    # Loop until you find the end
    while len(open_list) > 0:

        # Get the current node
        current_node = open_list[0]
        current_index = 0
        for index, item in enumerate(open_list):
            if item.f < current_node.f:
                current_node = item
                current_index = index

        # Pop current off open list, add to closed list
        open_list.pop(current_index)
        closed_map[current_node.position] = 1

        # Found the goal
        if current_node == end_node:
            path = []
            current = current_node
            while current is not None:
                path.append(i2w(current.position))
                current = current.parent
            return path[::-1]  # Return reversed path

        # Generate children
        for new_position in [(0, -1), (0, 1), (-1, 0), (1, 0)]:  # Adjacent squares

            # Get node position
            node_position = (
                current_node.position[0] + new_position[0], current_node.position[1] + new_position[1])

            # Make sure within range
            if node_position[0] > (len(maze) - 1) or node_position[0] < 0 or node_position[1] > (len(maze[len(maze)-1]) - 1) or node_position[1] < 0:
                continue

            # Make sure walkable terrain
            if maze[node_position[0]][node_position[1]] != 0:
                continue

            # Child is on the closed list
            if closed_map[node_position] != 0:
                continue

            # Create new node
            child = Node(current_node, node_position)

            # Create the f, g, and h values
            child.g = current_node.g + 1
            child.h = (((child.position[0] - end_node.position[0]) **
                       2) + ((child.position[1] - end_node.position[1]) ** 2))**0.5
            child.f = child.g + child.h

            # Child is already in the open list
            for i in range(len(open_list)):
                if child == open_list[i]:
                    if child.g < open_list[i].g:
                        open_list[i] = child
                    break
            else:
                # Add the child to the open list
                open_list.append(child)


def car_drive(path, car_pos, car_angle, scale):

    for des_pos in path:
        m = (des_pos[0]-car_pos[0], des_pos[1]-car_pos[1])
        if m == (-1, 0):
            des_angle = 180
        elif m == (0, 1):
            des_angle = 90
        elif m == (1, 0):
            des_angle = 0
        elif m == (0, -1):
            des_angle = -90
        else:
            print('bug!!!! wrong m', m, des_pos, car_pos)
        ma = (des_angle-car_angle) % 360

        if ma == 0:
            pass
        elif ma == 90:
            fc.turn_left(power)
            time.sleep(time_turn_left)
            fc.stop()
        elif ma == 180:

            fc.turn_left(power)
            time.sleep(time_turn_left)
            fc.stop()
            time.sleep(0.2)
            fc.turn_left(power)
            time.sleep(time_turn_left)
            fc.stop()

        elif ma == 270:

            fc.turn_right(power)
            time.sleep(time_turn_right)
            fc.stop()

        time.sleep(0.5)
        fc.forward(power)
        time.sleep(time_forward * scale)
        fc.stop()
        time.sleep(0.5)
        car_pos = des_pos
        car_angle = des_angle
        print('driving car to', car_pos, car_angle)

    return car_pos, car_angle


def detect_init(model: str, camera_id: int, width: int, height: int, num_threads: int,
                enable_edgetpu: bool):
    # Start capturing video input from the camera
    cap = cv2.VideoCapture(camera_id)
    cap.set(cv2.CAP_PROP_FRAME_WIDTH, width)
    cap.set(cv2.CAP_PROP_FRAME_HEIGHT, height)

    # Initialize the object detection model
    base_options = core.BaseOptions(
        file_name=model, use_coral=enable_edgetpu, num_threads=num_threads)
    detection_options = processor.DetectionOptions(
        max_results=3, score_threshold=0.3)
    options = vision.ObjectDetectorOptions(
        base_options=base_options, detection_options=detection_options)
    detector = vision.ObjectDetector.create_from_options(options)

    return cap, detector


def detect_halt(cap, detector) -> None:
    """Continuously run inference on images acquired from the camera.
    Args:
      model: Name of the TFLite object detection model.
      camera_id: The camera id to be passed to OpenCV.
      width: The width of the frame captured from the camera.
      height: The height of the frame captured from the camera.
      num_threads: The number of CPU threads to run the model.
      enable_edgetpu: True/False whether the model is a EdgeTPU model.
    """

    # Variables to calculate FPS
    # counter, fps = 0, 0
    # start_time = time.time()

    # Visualization parameters
    # row_size = 20  # pixels
    # left_margin = 24  # pixels
    # text_color = (0, 0, 255)  # red
    # font_size = 1
    # font_thickness = 1
    # fps_avg_frame_count = 10

    # Continuously capture images from the camera and run inference
    if cap.isOpened():
        success, image = cap.read()
        if not success:
            sys.exit(
                'ERROR: Unable to read from webcam. Please verify your webcam settings.'
            )

        # counter += 1
        image = cv2.flip(image, -1)

        # Convert the image from BGR to RGB as required by the TFLite model.
        rgb_image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)

        # Create a TensorImage object from the RGB image.
        input_tensor = vision.TensorImage.create_from_array(rgb_image)

        # Run object detection estimation using the model.
        detection_result = detector.detect(input_tensor)

        # Draw keypoints and edges on input image
        # image = utils.visualize(image, detection_result)

        # Calculate the FPS
        # if counter % fps_avg_frame_count == 0:
        #     end_time = time.time()
        #     fps = fps_avg_frame_count / (end_time - start_time)
        #     start_time = time.time()

        # Show the FPS
        # fps_text = 'FPS = {:.1f}'.format(fps)
        # text_location = (left_margin, row_size)
        # cv2.putText(image, fps_text, text_location, cv2.FONT_HERSHEY_PLAIN,
        #             font_size, text_color, font_thickness)

        # Stop the program if the ESC key is pressed.
        # if cv2.waitKey(1) == 27:
        #     break
        # cv2.imshow('object_detector', image)

        detected = False
        for detection in detection_result.detections:
            # Draw label and score
            category = detection.categories[0]
            category_name = category.category_name

            bbox = detection.bounding_box
            if 'stop sign' in category_name and (bbox.width > 100 or bbox.height > 100):
                detected = True
    else:
        print('cap not opened')

    return detected


def get_args():
    parser = argparse.ArgumentParser(
        formatter_class=argparse.ArgumentDefaultsHelpFormatter)
    parser.add_argument(
        '--model',
        help='Path of the object detection model.',
        required=False,
        default='efficientdet_lite0.tflite')
    parser.add_argument(
        '--cameraId', help='Id of camera.', required=False, type=int, default=0)
    parser.add_argument(
        '--frameWidth',
        help='Width of frame to capture from camera.',
        required=False,
        type=int,
        default=640)
    parser.add_argument(
        '--frameHeight',
        help='Height of frame to capture from camera.',
        required=False,
        type=int,
        default=480)
    parser.add_argument(
        '--numThreads',
        help='Number of CPU threads to run the model.',
        required=False,
        type=int,
        default=4)
    parser.add_argument(
        '--enableEdgeTPU',
        help='Whether to run the model on EdgeTPU.',
        action='store_true',
        required=False,
        default=False)
    parser.add_argument(
        '--x',
        help='x',
        required=False,
        type=int,
        default=0)
    parser.add_argument(
        '--y',
        help='y',
        required=False,
        type=int,
        default=0)
    args = parser.parse_args()

    return args


def scan_obstacles(map_car, car_pos, car_angle, scale):
    xp, yp = None, None

    # scanning
    for angle in range(-90, 90, 5):
        dis = fc.get_distance_at(angle)

        dis = dis/scale

        # timeout or obstacles too far away
        if dis <= 0:  # or dis > 200:
            xp, yp = None, None
            continue

        # car coordinate
        x = round(np.cos(np.radians(angle+car_angle)) * dis)
        y = round(np.sin(np.radians(angle+car_angle)) * dis)

        # world coordinate
        x = x + car_pos[0]
        y = y + car_pos[1]

        # image coordinate
        x, y = w2i((x, y))

        map_car = cv2.line(map_car, (x, y), (x+1, y+1),
                           color=255, thickness=round(15/scale), lineType=cv2.LINE_4)

        # draw line if previous xy exists
        if xp is not None:
            map_car = cv2.line(map_car, (x, y), (xp, yp),
                               color=255, thickness=round(15/scale), lineType=cv2.LINE_4)

        xp, yp = x, y

    return map_car


def w2i(pos):
    return (pos[0]+99, 100-pos[1])


def i2w(pos):
    return (pos[0]-99, 100-pos[1])


def navigate_to(args, cap, detector):

    target = (args.x, args.y)

    # init params
    scale = 5  # max(target)/90
    map_car = np.zeros((199, 199), dtype=np.int8)

    detected = False

    # init car attributes
    target = (round(target[0]/scale), round(target[1]/scale))
    car_pos = (0, 0)
    car_angle = 90

    # driving
    count = 0
    while (car_pos != target) and count < 250:
        count += 1
        if not detected:
            detected = detect_halt(cap, detector)
            if detected:
                print('detected! halt!')
                fc.stop()
                time.sleep(20)
                print('halt finished!')
            else:
                print('not detected')

        map_car = scan_obstacles(map_car, car_pos, car_angle, scale)
        print(map_car)
        path = astar(map_car, car_pos, target)
        path = path[1:min(6, len(path))]
        print('path:', path)

        car_pos, car_angle = car_drive(path, car_pos, car_angle, scale)

    ma = (90-car_angle) % 360

    if ma == 0:
        pass
    elif ma == 90:
        fc.turn_left(power)
        time.sleep(time_turn_left)
        fc.stop()
    elif ma == 180:

        fc.turn_left(power)
        time.sleep(time_turn_left)
        fc.stop()
        time.sleep(0.2)
        fc.turn_left(power)
        time.sleep(time_turn_left)
        fc.stop()

    elif ma == 270:

        fc.turn_right(power)
        time.sleep(time_turn_right)
        fc.stop()


if __name__ == '__main__':

    try:

        args = get_args()
        cap, detector = detect_init(args.model, int(args.cameraId), args.frameWidth, args.frameHeight,
                                    int(args.numThreads), bool(args.enableEdgeTPU))
        args.x = 50
        args.y = 125
        navigate_to(args, cap, detector)

        time.sleep(10)

        args.x = -50
        args.y = 125
        navigate_to(args, cap, detector)

        cap.release()
        cv2.destroyAllWindows()
        print('arrived')
    except:
        print('exception! stopped!')
        traceback.print_exc()
    finally:
        fc.stop()
