export DISPLAY=:0.0
libcamerify python3 step6.py