export DISPLAY=:0.0
libcamerify python3 step8.py