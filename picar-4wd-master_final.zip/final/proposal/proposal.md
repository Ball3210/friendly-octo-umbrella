# Final Project Proposal

## Motivation

In the final project we would try to extend the auto-pilot capability of Picar to better satisfy real-world driving needs. Currently, one limitation of our auto-pilot system in real-world is that, the detection model we used could only detect traffic light without distinguishing between 3  traffic light colors.  Therefore, our first goal is to enhance the detection model so that it can recognize the color of all detected traffic lights, without drastically increase computational complexity. Another current limitation of our Picar is that it can not receive control signals efficiently from human driver. In order to address this, our second goal is to establish a communication system between the process running on computer and on Picarm, so that it can respond and act in accordance with control commands. 

## Proposed Method

First, we propose to use transfer learning for traffic light color recognition.  Transfer learning is one of the deep learning technology which transfer the knowledge learned by a source model to a new target model. It is particularly suitable for the case where we have very limited GPU resources or limited amount of training data, but we have a pretrained model on related tasks. In these cases, training a new model from scratch is either infeasible or subject to overfitting. Transfer learning can effectively accelerate training process and enhance the performance. 

Second, we propose to create an efficient server-client communication system between computer and Picar. The system would be based on TCP protocol and our own specially designed application layer protocol. TCP protocol would provide a reliable connection, and our new application layer protocol can minimize the overhead of communication compared to using HTTP etc.

These proposed technologies are important in current IoT research and industries, and they can enrich the technology sets of all participants.

## Timeline

- 10/15: collect a dataset of traffic light images using Picar
- 10/30: fine-tune the detection model using transfer learning so that it can recognize different colors
- 11/15: implement our application layer protocol and the communication system
- 11/30: assemble and debug the whole system, write the report, prepare the video presentation

## Group Cooperation

- Bo Zhang (NetID: zhang375): responsible for dataset collection, communication system implementation, report writing
- Yizhuo Chen (NetID: yizhuoc): responsible for transfer learning implementation, communication system implementation, report writing
