import socket
import threading

IS_CONTROL = 0b00001000
IS_MOVE = 0b00000100
MOVE_W = 0b00000000
MOVE_A = 0b00000001
MOVE_S = 0b00000010
MOVE_D = 0b00000011
 
class RecvThread (threading.Thread):
    def __init__(self, threadID, name, client):
        threading.Thread.__init__(self)
        self.threadID = threadID
        self.name = name
        self.client= client
    def run(self):
        print("Starting " + self.name)
        while 1:
            try:
                d = self.client.recv(1)
                d = ord(d)
                if d & IS_CONTROL:
                    if d & IS_MOVE:
                        pass
                    else:
                        pass
                else:
                    d = self.client.recv(1)
                    d = ord(d)
                    d = self.client.recv(d)
                    print(d)
            except:
                print('exception')
                break
        
        print("Exiting " + self.name)

HOST = "192.168.1.110" # IP address of your Raspberry PI
PORT = 65432          # The port used by the server

with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
    s.connect((HOST, PORT))
    recv_thread = RecvThread(1,'recv_thread',s)
    recv_thread.start()
    while 1:
        text = input("Enter your message: ") # Note change to the old (Python 2) raw_input
        if text == "quit":
            print('quiting')
            break
        elif text == 'w':
            msg = IS_CONTROL | IS_MOVE | MOVE_W
        elif text == 'a':
            msg = IS_CONTROL | IS_MOVE | MOVE_A
        elif text == 's':
            msg = IS_CONTROL | IS_MOVE | MOVE_S
        elif text == 'd':
            msg = IS_CONTROL | IS_MOVE | MOVE_D
        elif text == 'h':
            msg = IS_CONTROL
        else:
            print('illegal input, try again')
            continue
        s.send(chr(msg).encode())     # send the encoded message (send in binary format)

recv_thread.join()

print('socket closed')