import socket
import threading
import time
import picar_4wd as fc

IS_CONTROL = 0b00001000
IS_MOVE = 0b00000100
MOVE_W = 0b00000000
MOVE_A = 0b00000001
MOVE_S = 0b00000010
MOVE_D = 0b00000011

POWER = 8
 
class RecvThread (threading.Thread):
    def __init__(self, threadID, name, client):
        threading.Thread.__init__(self)
        self.threadID = threadID
        self.name = name
        self.client= client
    def run(self):
        print("Starting " + self.name)
        while 1:
            try:
                d = self.client.recv(1)
                d = ord(d)
                if d & IS_CONTROL:
                    if d & IS_MOVE:
                        d = d & MOVE_D
                        if d == MOVE_W:
                            fc.forward(POWER)
                        elif d == MOVE_A:
                            fc.turn_left(POWER)
                        elif d == MOVE_S:
                            fc.backward(POWER)
                        elif d == MOVE_D:
                            fc.turn_right(POWER)
                        print('move')
                        
                    else:
                        print('halt')
                        fc.stop()
                else:
                    pass
            except:
                print('exception')
                fc.stop()
                break
        
        print("Exiting " + self.name)
 

HOST = "192.168.1.110" # IP address of your Raspberry PI
PORT = 65432          # Port to listen on (non-privileged ports are > 1023)

with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
    s.bind((HOST, PORT))
    s.listen()
    client, clientInfo = s.accept()
    recv_thread = RecvThread(1,'recv_thread',client)
    recv_thread.start()
    try:
        while 1:
            time.sleep(0.5)

            min_dis = 9999
            min_angle = -90
            for angle in range(-90, 90, 5):
                dis = fc.get_distance_at(angle)
                if dis < 0:
                    continue
                if dis < min_dis:
                    min_dis = dis
                    min_angle = angle

            msg = f'This is a report from picar. The closest object is {min_dis} cm away at angle {min_angle}.'
            if min_dis < 30:
                fc.stop()
                msg += ' It is too close! The car halted!'
            msg = chr(0b00000000)+chr(len(msg)) + msg
            client.sendall(msg.encode()) # Echo back to client
    except: 
        print("Closing socket")
        fc.stop()
        
    recv_thread.join()

print('socket closed')
fc.stop()