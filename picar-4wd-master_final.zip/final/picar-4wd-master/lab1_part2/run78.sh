export DISPLAY=:0.0
libcamerify python3 step78.py