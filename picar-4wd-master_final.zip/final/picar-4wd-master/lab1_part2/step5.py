import picar_4wd as fc
import numpy as np
import cv2


def plot_map(map_car):

    # map_car = cv2.rotate(map_car, cv2.ROTATE_90_COUNTERCLOCKWISE)
    while True:
        if cv2.waitKey(1) == 27:
            break
        cv2.imshow('current_map', map_car)


def main():
    map_car = np.zeros((199, 199), dtype=np.int8)
    # the car is at (0, 0)
    # x or y is within the range of [-99,99]

    xp, yp = None, None

    # scanning
    for angle in range(-90, 90, 5):
        dis = fc.get_distance_at(angle)
        print(dis)

        # timeout or obstacles too far away
        if dis <= 0:  # or dis > 200:
            xp, yp = None, None
            continue

        x = round(np.cos(np.radians(angle+90)) * dis)
        y = round(np.sin(np.radians(angle+90)) * dis)

        x = x + 99
        y = 100 - y
        print(x, y)

        map_car = cv2.line(map_car, (x, y), (x+1, y+1),
                            color=120, thickness=2, lineType=cv2.LINE_4)

        # draw line if previous xy exists
        if xp is not None:
            map_car = cv2.line(map_car, (x, y), (xp, yp),
                               color=120, thickness=2, lineType=cv2.LINE_4)
            print(f'drawline with {xp},{yp}')

        xp, yp = x, y

    plot_map(map_car)


if __name__ == "__main__":
    try:
        main()
    finally:
        print('exception! car stopped!')
        fc.stop()
