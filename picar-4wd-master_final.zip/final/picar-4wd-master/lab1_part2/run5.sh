export DISPLAY=:0.0
python3 step5.py