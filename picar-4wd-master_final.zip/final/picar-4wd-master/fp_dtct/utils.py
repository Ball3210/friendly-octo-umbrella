# Copyright 2021 The TensorFlow Authors. All Rights Reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
"""Utility functions to display the pose detection results."""

import cv2
import numpy as np
import pickle

_MARGIN = 10  # pixels
_ROW_SIZE = 10  # pixels
_FONT_SIZE = 1
_FONT_THICKNESS = 1
_TEXT_COLOR = (0, 0, 255)  # red

with open('labels.txt', 'r') as f:
    lines = f.readlines()

with open('clf.pkl', 'rb') as f:
    clf = pickle.load(f)


def visualize(
    image: np.ndarray,
    detection
) -> np.ndarray:
    """Draws bounding boxes on the input image and return it.
    Args:
      image: The input RGB image.
      detection_result: The list of all "Detection" entities to be visualize.
    Returns:
      Image with bounding boxes.
    """
    boxes = detection['boxes'].detach().cpu().numpy()
    labels = detection['labels'].detach().cpu().numpy()
    for idx in range(len(detection['labels'])):        # Draw bounding_box
        probability = round(detection['scores'][idx].detach().item(), 2)
        if probability < 0.2:
          continue
        bbox = boxes[idx]
        start_point = int(bbox[0]), int(bbox[1])
        end_point = int(bbox[2]), int(bbox[3])
        # print(bbox, start_point)
        cv2.rectangle(image, start_point, end_point, _TEXT_COLOR, 3)

        # Draw label and score
        category = labels[idx]
        category_name = lines[category-1][:-1]

        if category == 10:
            feature = detection['features'][idx:idx+1].detach().cpu().numpy()
            pred = clf.predict(feature)[0]
            if pred == 0:
                category_name += '_red'
            elif pred == 1:
                category_name += '_yellow'
            elif pred == 2:
                category_name += '_green'

        
        result_text = category_name + ' (' + str(probability) + ')'
        text_location = (_MARGIN + start_point[0],
                         _MARGIN + _ROW_SIZE + start_point[1])

        cv2.putText(image, result_text, text_location, cv2.FONT_HERSHEY_PLAIN,
                    _FONT_SIZE, _TEXT_COLOR, _FONT_THICKNESS)

    return image
